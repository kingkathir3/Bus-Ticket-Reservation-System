package com.busreservation.exception;

public class CustomerNotFound extends Exception{

	public CustomerNotFound() {
		
	}
	
	public CustomerNotFound(String message){
		super(message);
	}
}
